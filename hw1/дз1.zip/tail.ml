let rec factorial n =
  match n with
  | 0 -> 1
  | n -> n * (factorial (n - 1))

let () =
  factorial 3
  |> Printf.printf "%i\n"



(* Не хвостово-рекурсивная! *)
let rec filter f l =
  match l with
  | [] -> []
  | x::xs ->
    if f x then
      x::(filter f xs)
    else
      filter f xs

let even x =
  x mod 2 = 0

let () =
  [1; 2; 5; 7; 34]
  |> filter even
  |> List.iter (Printf.printf "%i ")
